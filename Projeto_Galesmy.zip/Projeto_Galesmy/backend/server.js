const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const produtosRoutes = require('./routes/produtos');
// IMPORTA el seed además del router:
const { router: initUserRouter, seedAdmin } = require('./routes/initUser');
const usuariosRouter = require('./routes/usuarios');

const app = express();
app.use(cors());
app.use(express.json());

// Conexión a MongoDB Atlas
mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    console.log('✅ Conectado a MongoDB Atlas');

    // Ejecuta el seed UNA sola vez por arranque (idempotente)
    try {
      const r = await seedAdmin();
      console.log(r?.created ? '👤 Admin creado automáticamente.' : '👤 Admin ya existía.');
    } catch (e) {
      console.error('Seed admin falló:', e);
    }
  })
  .catch(err => console.error('❌ Erro ao conectar ao MongoDB:', err));

// Rutas de la API
app.use('/api/produtos', produtosRoutes);
app.use('/api/init', initUserRouter);      // endpoint opcional para disparo manual
app.use('/api/usuarios', usuariosRouter);

// Inicialización del servidor
app.listen(3000, () => {
  console.log('🚀 Servidor rodando na porta 3000: http://localhost:3000');
});
