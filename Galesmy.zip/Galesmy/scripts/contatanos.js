// Waits for the full DOM to load before executing the script
document.addEventListener("DOMContentLoaded", () => {

  // Retrieves the currently logged user from sessionStorage (temporary session storage)
  const usuario = JSON.parse(sessionStorage.getItem("loggedUser"));

  // Verifies whether the user is authenticated and has a valid name
  if (!usuario || !usuario.name) {
    alert("Você precisa estar logado para enviar uma mensagem."); // Alert if user is not logged in
    window.location.href = "loginpage.html"; // Redirect to login page
    return; // Stop script execution
  }

  // Auto-fill the name and email fields with the logged user's data
  document.getElementById("name").value = usuario.name;
  document.getElementById("email").value = usuario.email;

  // Select the contact form using its CSS class
  const form = document.querySelector(".contact-form");

  // Add an event listener to handle form submission
  form.addEventListener("submit", async function(event) {
    event.preventDefault(); // Prevent default form submission behavior (page reload)

    // Create a FormData object with the current form fields
    const formData = new FormData(form);

    try {
      // Send the form data to Formspree using a POST request
      const response = await fetch("https://formspree.io/f/mvgalepo", {
        method: "POST",
        body: formData, // Send form fields as multipart/form-data
        headers: {
          Accept: "application/json" // Expect JSON response from Formspree
        }
      });

      // Handle successful response
      if (response.ok) {
        alert("Mensagem enviada com sucesso!"); // Inform user of success
        form.reset(); // Clear form fields
      } else {
        alert("Erro ao enviar. Tente novamente."); // Handle failed response
      }
    } catch (error) {
      // Handle network or unexpected runtime errors
      alert("Erro inesperado: " + error.message);
    }
  });
});
