// Wait until the entire DOM is loaded before running the script
document.addEventListener("DOMContentLoaded", () => {

  // Select the form element by its ID
  const form = document.getElementById("form-add-produto");

  // Add a submit event listener to the form
  form.addEventListener("submit", async (e) => {
    e.preventDefault(); // Prevent the default form submission behavior

    // Construct a new product object from the form fields
    const novoProduto = {
      nome: document.getElementById("nome").value.trim(),           // Product name
      descricao: document.getElementById("descricao").value.trim(), // Description
      imagem: document.getElementById("imagem").value.trim(),       // Image URL or path
      preco: parseFloat(document.getElementById("preco").value),    // Price (converted to float)
      estoque: parseInt(document.getElementById("estoque").value),  // Stock quantity (integer)
      vendidos: parseInt(document.getElementById("vendidos").value),// Units sold (integer)
      categoria: document.getElementById("categoria").value,        // Product category (string)
      marca: document.getElementById("marca").value.trim(),         // Brand (string)
      apresentacao: document.getElementById("unidade").value        // Presentation/unit of measurement
    };

    // ✅ Basic validation for numeric fields
    if (isNaN(novoProduto.preco) || isNaN(novoProduto.estoque)) {
      alert("Preencha corretamente todos os campos numéricos."); // Show alert if price or stock is invalid
      return;
    }

    try {
      // Send the new product to the backend API using a POST request
      const resposta = await fetch("http://localhost:3000/api/produtos", {
        method: "POST",
        headers: {
          "Content-Type": "application/json" // Indicate that the body is in JSON format
        },
        body: JSON.stringify(novoProduto) // Convert the product object to JSON string
      });

      // If response is not successful, throw an error
      if (!resposta.ok) {
        throw new Error("Erro ao salvar produto.");
      }

      // On success, notify the user and redirect to the admin page
      alert("Produto adicionado com sucesso!");
      window.location.href = "admin-productos.html";

    } catch (erro) {
      // Catch and display network or server errors
      console.error("Erro:", erro);
      alert("Erro ao salvar o produto.");
    }
  });
});
