// Utility function to extract a parameter from the URL (e.g., ?id=5)
function getParamFromURL(name) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name); // Return value of given parameter
}

// Retrieve the product ID from the URL as a string
const id = getParamFromURL("id");

let produto = null;

// 🔄 Fetch product data from backend API using the given ID
fetch(`http://localhost:3000/api/produtos/${id}`)
  .then(res => {
    if (!res.ok) throw new Error("Produto não encontrado"); // Handle 404 or error
    return res.json(); // Parse response as JSON
  })
  .then(data => {
    produto = data;

    // 🖊 Populate the product details on the page
    document.getElementById("produto-nome").textContent = produto.nome;
    document.getElementById("produto-descricao").textContent = produto.descricao;
    document.getElementById("produto-marca").textContent = produto.marca;
    document.getElementById("produto-preco").textContent = `R$ ${produto.preco.toFixed(2)}`;
    document.getElementById("produto-img").src = produto.imagem;
    document.getElementById("produto-apresentacao").textContent = produto.apresentacao;
    document.getElementById("produto-quantidade").textContent = produto.estoque;

    // Set default quantity input value to 1
    document.getElementById("quantidade").value = 1;
  })
  .catch(err => {
    // If product not found, log the error and replace body with message
    console.error(err);
    document.body.innerHTML = "<h2>Produto não encontrado</h2>";
  });

// ➕➖ Function to increase or decrease quantity input
function alterarQuantidade(delta) {
  const input = document.getElementById("quantidade");
  let valor = parseInt(input.value);
  const estoque = parseInt(document.getElementById("produto-quantidade").textContent);

  if (isNaN(valor)) valor = 1;
  valor += delta;
  if (valor < 1) valor = 1;
  if (valor > estoque) {
    alert("Quantidade excede o estoque disponível.");
    valor = estoque;
  }

  input.value = valor; // Update quantity field
}

// 🛒 Function to add product to the cart
function adicionarAoCarrinho() {
  const input = document.getElementById("quantidade");
  let quantidade = parseInt(input.value);

  // Validate product data and quantity
  if (!produto || quantidade < 1 || isNaN(quantidade)) {
    alert("Dados inválidos ou produto não carregado.");
    return;
  }

  // Load current cart from sessionStorage
  let carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];

  // Check if product is already in cart
  const existente = carrinho.find(item => item._id === produto._id);
  const quantidadeAtual = existente ? existente.quantidade : 0;
  const totalDesejado = quantidadeAtual + quantidade;

  // Prevent exceeding stock
  if (totalDesejado > produto.estoque) {
    alert(`Quantidade total excede o estoque disponível. Estoque máximo: ${produto.estoque}`);
    input.value = produto.estoque - quantidadeAtual > 0 ? produto.estoque - quantidadeAtual : 0;
    return;
  }

  // Update quantity if product exists, otherwise add to cart
  if (existente) {
    existente.quantidade += quantidade;
  } else {
    carrinho.push({
      _id: produto._id,
      nome: produto.nome,
      marca: produto.marca,
      preco: produto.preco,
      imagem: produto.imagem,
      quantidade: quantidade
    });
  }

  // Save updated cart to sessionStorage
  sessionStorage.setItem("carrinho", JSON.stringify(carrinho));

  alert("Produto adicionado ao carrinho!");
  window.location.href = "../pages/Produtos_Page.html"; // Redirect to cart page
}
