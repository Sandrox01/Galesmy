// Wait for the full DOM to load before executing the script
document.addEventListener("DOMContentLoaded", () => {

  // Retrieve the logged-in user data stored in sessionStorage (as JSON)
  const user = JSON.parse(sessionStorage.getItem("loggedUser"));

  // If no user is logged in, show an alert and redirect to the login page
  if (!user) {
    alert("Nenhum usuário logado. Redirecionando para o login...");
    window.location.href = "loginpage.html";
    return; // Stop further execution
  }

  // Inject user data into respective HTML elements
  // The nullish coalescing operator (??) provides a fallback ("-") if a value is null or undefined
  document.getElementById("user-doc").textContent     = user.CPF     ?? "-"; // CPF
  document.getElementById("user-name").textContent    = user.name    ?? "-"; // User name
  document.getElementById("user-address").textContent = user.address ?? "-"; // Address
  document.getElementById("user-phone").textContent   = user.phone   ?? "-"; // Phone
  document.getElementById("user-email").textContent   = user.email   ?? "-"; // Email

  // Display a personalized welcome message
  document.getElementById("bienvenida").textContent = `Bem-vindo, ${user.name}!`;

  // Reference to the <span> that shows the password and the toggle button
  const passwordSpan = document.getElementById("user-password");
  const toggleButton = document.getElementById("toggle-password");

  // State variable to track password visibility
  let senhaVisivel = false;

  // Initially mask the password with dots (•) — one per character
  passwordSpan.textContent = user.password.replace(/./g, "•");

  // Handle click event to toggle password visibility
  toggleButton.addEventListener("click", () => {
    if (senhaVisivel) {
      // If currently visible, mask the password again
      passwordSpan.textContent = user.password.replace(/./g, "•");
      toggleButton.title = "Mostrar senha"; // Update tooltip
      senhaVisivel = false; // Update state
    } else {
      // If currently hidden, display password in plain text
      passwordSpan.textContent = user.password;
      toggleButton.title = "Ocultar senha"; // Update tooltip
      senhaVisivel = true; // Update state
    }
  });

  // -----------------------------
  //   TROCA DE FOTO DE PERFIL
  // -----------------------------

  const avatarImg   = document.getElementById("user-avatar");
  const avatarInput = document.getElementById("avatar-input");

  // Chave no localStorage baseada no email do usuário
  const AVATAR_STORAGE_KEY = user.email
    ? `galesmy_avatar_${user.email}`
    : "galesmy_avatar_default_user";

  function loadUserAvatar() {
    if (!avatarImg) return;
    const savedAvatar = localStorage.getItem(AVATAR_STORAGE_KEY);
    if (savedAvatar) {
      avatarImg.src = savedAvatar;
    }
  }

  function saveUserAvatar(dataUrl) {
    try {
      localStorage.setItem(AVATAR_STORAGE_KEY, dataUrl);
    } catch (e) {
      console.warn("Não foi possível salvar a foto no localStorage (tamanho muito grande?):", e);
    }
  }

  if (avatarInput && avatarImg) {
    avatarInput.addEventListener("change", (event) => {
      const file = event.target.files[0];
      if (!file) return;

      if (!file.type.startsWith("image/")) {
        alert("Por favor, selecione um arquivo de imagem.");
        avatarInput.value = "";
        return;
      }

      const reader = new FileReader();

      reader.onload = (e) => {
        const dataUrl = e.target.result;
        avatarImg.src = dataUrl;
        saveUserAvatar(dataUrl);
      };

      reader.readAsDataURL(file);
    });
  }

  // Carrega a foto salva (se existir) assim que a página do usuário abre
  loadUserAvatar();

});
