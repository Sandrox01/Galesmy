document.addEventListener("DOMContentLoaded", async () => {
  // 🔎 Retrieve the user ID stored earlier in localStorage
  const idUsuario = localStorage.getItem("editandoUsuarioId");

  // If the user ID is not available, alert and stop execution
  if (!idUsuario) {
    alert("ID do usuário não fornecido."); // User ID not provided
    return;
  }

  let usuario;

  // 🔄 Fetch user data from the backend API using the user ID
  try {
    const res = await fetch(`http://localhost:3000/api/usuarios/${idUsuario}`);
    if (!res.ok) throw new Error("Usuário não encontrado."); // Handle fetch failure
    usuario = await res.json(); // Parse the response JSON
  } catch (err) {
    console.error("Erro ao buscar usuário:", err); // Log error for debugging
    alert("Erro ao carregar dados do usuário."); // Alert user
    return;
  }

  // 📝 Populate the form fields with the user data retrieved from MongoDB
  document.getElementById("id").value        = usuario._id;
  document.getElementById("nome").value      = usuario.name;
  document.getElementById("email").value     = usuario.email;
  document.getElementById("telefone").value  = usuario.phone;
  document.getElementById("endereco").value  = usuario.address;
  document.getElementById("cpf").value       = usuario.CPF;
  document.getElementById("role").value      = usuario.role;
  document.getElementById("status").value    = usuario.ativo === false ? "inativo" : "ativo";

  // 💾 Handle form submission to update user data
  document.getElementById("form-usuario").addEventListener("submit", async (e) => {
    e.preventDefault(); // Prevent default form behavior

    // 📦 Construct the updated user object from form values
    const usuarioAtualizado = {
      name:      document.getElementById("nome").value.trim(),
      email:     document.getElementById("email").value.trim(),
      phone:     document.getElementById("telefone").value.trim(),
      address:   document.getElementById("endereco").value.trim(),
      CPF:       document.getElementById("cpf").value.trim(),
      role:      document.getElementById("role").value,
      ativo:     document.getElementById("status").value === "ativo" // Convert string to boolean
    };

    try {
      // Send a PUT request to update the user record in the backend (MongoDB Atlas)
      const response = await fetch(`http://localhost:3000/api/usuarios/${idUsuario}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" }, // Specify JSON payload
        body: JSON.stringify(usuarioAtualizado)
      });

      // Handle unsuccessful response
      if (!response.ok) throw new Error("Erro ao atualizar usuário");

      alert("Usuário atualizado com sucesso!"); // Notify user
      localStorage.removeItem("editandoUsuarioId"); // Remove temp ID
      window.location.href = "admin-usuarios.html"; // Redirect to user admin page
    } catch (error) {
      console.error("Erro ao atualizar:", error); // Log update failure
      alert("Erro ao atualizar usuário."); // Notify error
    }
  });
});
