// Waits for the full DOM to be loaded before running the script
document.addEventListener("DOMContentLoaded", () => {

  // Get input elements for CPF, phone, and name
  const cpfInput = document.getElementById("documento");
  const phoneInput = document.getElementById("telefone");
  const nameInput = document.getElementById("nome");

  // CPF input mask: formats input as XXX.XXX.XXX-XX
  cpfInput.addEventListener("input", () => {
    let value = cpfInput.value.replace(/\D/g, ""); // Remove all non-digit characters
    if (value.length > 11) value = value.slice(0, 11); // Limit to 11 digits
    value = value.replace(/(\d{3})(\d)/, "$1.$2")     // First dot
                 .replace(/(\d{3})(\d)/, "$1.$2")     // Second dot
                 .replace(/(\d{3})(\d{1,2})$/, "$1-$2"); // Hyphen before last 2 digits
    cpfInput.value = value; // Set formatted value
  });

  // Phone input mask: formats as (XX) XXXXX-XXXX
  phoneInput.addEventListener("input", () => {
    let value = phoneInput.value.replace(/\D/g, ""); // Remove non-digit characters
    if (value.length > 11) value = value.slice(0, 11); // Limit to 11 digits
    value = value.replace(/^(\d{2})(\d)/, "($1) $2")   // Area code
                 .replace(/(\d{5})(\d)/, "$1-$2");     // Dash after five digits
    phoneInput.value = value; // Set formatted value
  });

  // Name input restriction: allow only letters and spaces (including accents)
  nameInput.addEventListener("input", () => {
    nameInput.value = nameInput.value.replace(/[^A-Za-zÀ-ÿ\s]/g, ""); // Disallow numbers/symbols
  });

  // Handle form submission for user registration
  const form = document.querySelector(".formulario-registro");
  form.addEventListener("submit", async function (event) {
    event.preventDefault(); // Prevent page reload

    // Construct the new user object with form data
    const novoUsuario = {
      CPF: cpfInput.value.trim(),
      name: nameInput.value.trim(),
      address: document.getElementById("endereco").value.trim(),
      phone: phoneInput.value.trim(),
      email: document.getElementById("email").value.trim(),
      password: document.getElementById("senha").value,
      role: "client" // Default role for client registration
    };

    try {
      // Send POST request to backend to register the user (MongoDB Atlas connected API)
      const res = await fetch("http://localhost:3000/api/usuarios", {
        method: "POST",
        headers: { "Content-Type": "application/json" }, // Indicate JSON request
        body: JSON.stringify(novoUsuario) // Convert object to JSON string
      });

      // Handle server-side errors
      if (!res.ok) {
        const erro = await res.json();
        alert(erro.message || "Erro ao registrar usuário."); // Show backend message
        return;
      }

      // On success, store the user in session and redirect
      const userCriado = await res.json();
      sessionStorage.setItem("loggedUser", JSON.stringify(userCriado)); // Save session
      alert("Usuário registrado com sucesso!");
      window.location.href = "Produtos_Page.html"; // Redirect to main page
    } catch (error) {
      // Handle network or unexpected errors
      console.error("Erro de rede:", error);
      alert("Erro ao conectar com o servidor.");
    }
  });
});
