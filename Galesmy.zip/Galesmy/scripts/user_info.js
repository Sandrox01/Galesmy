// Wait for the DOM to be fully loaded before executing the script
document.addEventListener("DOMContentLoaded", () => {

  // Select the element where user information will be displayed
  const userInfo = document.getElementById("user-info");

  // Retrieve the currently logged-in user from sessionStorage
  const usuario = JSON.parse(sessionStorage.getItem("loggedUser"));

  // Check if a valid user is logged in (with a "name" field)
  if (usuario && usuario.name) {

    // Begin constructing the user menu HTML (profile name + default avatar)
    let menuHTML = `
      <div class="usuario-toggle">
        <div class="perfil" id="perfil-clickable">
          <span>${usuario.name}</span>
          <img src="../imagenes/default_user.png" alt="Usuário">
        </div>
        <div id="logout-opcoes" class="logout-menu">
          <button id="btn-logout" class="logout-button">Sair</button>
    `;

    // If the user has admin role, append an "Admin" button to the menu
    if (usuario.role === "admin") {
      menuHTML += `
        <button id="btn-admin" class="admin-button">Admin</button>
      `;
    }

    // Finalize the HTML structure of the dropdown menu
    menuHTML += `</div></div>`;

    // Insert the constructed HTML into the user-info container
    userInfo.innerHTML = menuHTML;

    // Reference to the clickable profile block (name + avatar)
    const perfilClickable = document.getElementById("perfil-clickable");

    // Reference to the dropdown menu containing logout/admin buttons
    const logoutMenu = document.getElementById("logout-opcoes");

    // Toggle dropdown visibility on profile click
    perfilClickable.addEventListener("click", () => {
      logoutMenu.classList.toggle("show"); // Toggle "show" class (CSS visibility)
    });

    // Add logout functionality
    document.getElementById("btn-logout").addEventListener("click", () => {
      sessionStorage.removeItem("loggedUser"); // End session
      window.location.href = "loginpage.html"; // Redirect to login
    });

    // If the "Admin" button is present (i.e., user is admin)
    const btnAdmin = document.getElementById("btn-admin");
    if (btnAdmin) {
      btnAdmin.addEventListener("click", () => {
        window.location.href = "admin-productos.html"; // Redirect to admin panel
      });
    }
  }
});
