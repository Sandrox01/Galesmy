// Wait for the DOM to be fully loaded before executing the script
document.addEventListener("DOMContentLoaded", () => {

  // ----- INPUT MASKS FOR CARD FORM FIELDS -----

  // Allows only letters and spaces in the "cardholder name" field
  document.getElementById("nome-cartao").addEventListener("input", e => {
    e.target.value = e.target.value.replace(/[^A-Za-zÀ-ÿ\s]/g, "");
  });

  // Formats the card number into groups of 4 digits
  document.getElementById("numero-cartao").addEventListener("input", e => {
    let val = e.target.value.replace(/\D/g, "").substring(0, 16);
    e.target.value = val.replace(/(\d{4})(?=\d)/g, "$1 ");
  });

  // Formats the expiration date as MM/YY
  document.getElementById("validade-cartao").addEventListener("input", e => {
    let val = e.target.value.replace(/\D/g, "").substring(0, 4);
    e.target.value = val.length > 2 ? val.replace(/(\d{2})(\d+)/, "$1/$2") : val;
  });

  // Allows only 3 numeric digits in the CVV field
  document.getElementById("cvv-cartao").addEventListener("input", e => {
    e.target.value = e.target.value.replace(/\D/g, "").substring(0, 3);
  });

  // ----- CALCULATE TOTAL PRICE BASED ON CART PRODUCTS -----

  const carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];
  const total = carrinho.reduce((acc, p) => acc + p.quantidade * p.preco, 0); // Sum total of all cart items
  const totalInput = document.getElementById("total");
  totalInput.value = `R$ ${total.toFixed(2).replace(".", ",")}`; // Format as currency
  totalInput.readOnly = true; // Make total field read-only

  // ----- HANDLE "CONFIRM PAYMENT" BUTTON EVENT -----

  document.getElementById("btn-confirmar").addEventListener("click", async (e) => {
    e.preventDefault(); // Prevent default form submission

    // Collect data from form inputs
    const nome = document.getElementById("nome-cartao").value.trim();
    const numero = document.getElementById("numero-cartao").value.trim();
    const validade = document.getElementById("validade-cartao").value.trim();
    const cvv = document.getElementById("cvv-cartao").value.trim();

    // Basic field validation
    if (!nome || numero.length < 19 || validade.length < 5 || cvv.length !== 3) {
      alert("Preencha corretamente todos os campos do cartão.");
      return;
    }

    // Call function to process the purchase and generate the PDF receipt
    await finalizarCompra();

    // Clear the form and redirect to the products page
    document.getElementById("form-pago").reset();
    window.location.href = "Produtos_Page.html";
  });
});
// -------- MAIN FUNCTION TO PROCESS THE PURCHASE --------
async function finalizarCompra() {
  const carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];
  const usuario = JSON.parse(sessionStorage.getItem("loggedUser")) || { name: "Usuário desconhecido" };

  // Stop if the cart is empty
  if (carrinho.length === 0) {
    alert("Carrinho vazio.");
    return;
  }

  // Iterate over each product in the cart to update stock and sold count
  for (let produto of carrinho) {
    let dadosProduto;
    try {
      // Fetch current product data from backend
      const res = await fetch(`http://localhost:3000/api/produtos/${produto._id}`);
      if (!res.ok) throw new Error("Produto não encontrado.");
      dadosProduto = await res.json();
    } catch (err) {
      console.error(`Erro ao consultar produto ${produto.nome}:`, err);
      alert("Erro ao consultar estoque do produto.");
      return;
    }

    // Calculate new stock and sold quantities
    const novoEstoque = dadosProduto.estoque - produto.quantidade;
    const novosVendidos = (dadosProduto.vendidos || 0) + produto.quantidade;

    try {
      // Update product data via PUT request to backend (MongoDB Atlas)
      const response = await fetch(`http://localhost:3000/api/produtos/${produto._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          estoque: novoEstoque,
          vendidos: novosVendidos
        })
      });

      if (!response.ok) throw new Error("Erro ao atualizar produto no servidor");
      console.log(`✔ Estoque atualizado: ${produto.nome}`);
    } catch (error) {
      console.error(`Erro ao atualizar produto ${produto.nome}:`, error);
      alert("Erro na compra. Tente novamente.");
      return;
    }
  }

  // After all products are updated, generate and download the receipt
  await gerarBoletaECriarDownload(carrinho, usuario);
  sessionStorage.removeItem("carrinho"); // Clear cart after purchase
}
// -------- GENERATE AND DOWNLOAD PURCHASE RECEIPT AS PDF --------
async function gerarBoletaECriarDownload(carrinho, usuario) {
  return new Promise(resolve => {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const agora = new Date();
    const data = agora.toLocaleDateString();
    const hora = agora.toLocaleTimeString();

    // Header
    doc.setFontSize(18);
    doc.setTextColor(40, 100, 70);
    doc.text("Galesmy Supermarkt", 14, 20);
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.text(`Cliente: ${usuario.name}`, 14, 30);
    doc.text(`Data: ${data} ${hora}`, 14, 38);

    // Table header and content rows
    const cabecalho = [["Produto", "Qtd", "Preço Unitário", "Subtotal"]];
    let total = 0;
    const linhas = carrinho.map(item => {
      const subtotal = item.quantidade * item.preco;
      total += subtotal;
      return [
        item.nome.length > 30 ? item.nome.slice(0, 27) + "..." : item.nome,
        item.quantidade.toString(),
        `R$ ${item.preco.toFixed(2)}`,
        `R$ ${subtotal.toFixed(2)}`
      ];
    });

    // Render the table using autoTable plugin
    doc.autoTable({
      head: cabecalho,
      body: linhas,
      startY: 45,
      styles: { fontSize: 10, cellPadding: 4 },
      headStyles: { fillColor: [117, 176, 91] },
      alternateRowStyles: { fillColor: [245, 245, 245] }
    });

    // Final total display
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.text(`TOTAL: R$ ${total.toFixed(2)}`, 14, doc.lastAutoTable.finalY + 10);

    // Download the PDF
    doc.save("boleta_compra.pdf");

    // Short delay before resolving the promise
    setTimeout(resolve, 100);
  });
}
