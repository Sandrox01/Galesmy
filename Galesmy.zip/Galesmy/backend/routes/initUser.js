const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const Usuario = require('../models/Usuario');

const ADMIN_EMAIL = 'galesmy@empresa.com'; // en minúsculas
const ADMIN_PASS  = 'admin123';

async function seedAdmin() {
  const existe = await Usuario.findOne({ email: ADMIN_EMAIL });
  if (existe) return { created: false, reason: 'exists' };

  const hash = await bcrypt.hash(ADMIN_PASS, 10);
  await Usuario.create({
    CPF: '000.000.000-00',
    name: 'Galesmy',
    address: 'Av. Central, 123 - São Paulo',
    phone: '(11) 99999-9999',
    email: ADMIN_EMAIL,
    password: ADMIN_PASS,
    role: 'admin',
    ativo: true
  });
  return { created: true };
}

// endpoint manual opcional
router.get('/admin', async (_req, res) => {
  try {
    const r = await seedAdmin();
    res.status(r.created ? 201 : 200).json({ message: r.created ? 'Admin creado' : 'Admin ya existe' });
  } catch (e) {
    res.status(500).json({ error: 'Error al crear admin' });
  }
});

module.exports = { router, seedAdmin };
