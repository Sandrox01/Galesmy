const express = require('express');
const router = express.Router();
const Usuario = require('../models/Usuario');

// 📌 [GET] Listar todos os usuários
router.get('/', async (req, res) => {
  try {
    const usuarios = await Usuario.find();
    res.json(usuarios);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao buscar usuários." });
  }
});

// 📌 [GET] Inicializa o admin se não existir
router.get('/admin', async (req, res) => {
  try {
    const existe = await Usuario.findOne({ email: "Galesmy@empresa.com" });
    if (existe) return res.status(200).json({ message: "Admin já existe." });

    const novoAdmin = new Usuario({
      CPF: "000.000.000-00",
      name: "Galesmy",
      address: "Av. Central, 123 - São Paulo",
      phone: "(11) 99999-9999",
      email: "Galesmy@empresa.com",
      password: "admin123",
      role: "admin",
      ativo: true
    });

    await novoAdmin.save();
    res.status(201).json({ message: "Admin criado com sucesso." });
  } catch (err) {
    res.status(500).json({ error: "Erro ao criar admin." });
  }
});

// 📌 [GET] Buscar usuário por ID
router.get('/:id', async (req, res) => {
  try {
    const usuario = await Usuario.findById(req.params.id);
    if (!usuario) return res.status(404).json({ erro: "Usuário não encontrado" });
    res.json(usuario);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao buscar usuário por ID" });
  }
});

router.post('/login', async (req, res) => {
  const { emailOuCPF, senha } = req.body;

  try {
    const usuario = await Usuario.findOne({
      $or: [{ email: emailOuCPF }, { CPF: emailOuCPF }]
    });

    if (!usuario || usuario.password !== senha) {
      return res.status(401).json({ erro: "Credenciais inválidas" });
    }

    res.json(usuario);
  } catch (err) {
    res.status(500).json({ erro: "Erro no login" });
  }
});


// 📌 [POST] Criar novo usuário
router.post('/', async (req, res) => {
  const { CPF, name, address, phone, email, password, role } = req.body;
  try {
    const jaExiste = await Usuario.findOne({ email });
    if (jaExiste) return res.status(400).json({ erro: "E-mail já cadastrado." });

    const novo = new Usuario({
      CPF, name, address, phone, email, password, role,
      ativo: true
    });

    await novo.save();
    res.status(201).json(novo);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao criar usuário." });
  }
});

// 📌 [PUT] Atualizar usuário por ID
router.put('/:id', async (req, res) => {
  try {
    const atualizado = await Usuario.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!atualizado) return res.status(404).json({ erro: "Usuário não encontrado" });
    res.json(atualizado);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao atualizar usuário." });
  }
});

// 📌 [DELETE] Excluir usuário por ID
router.delete('/:id', async (req, res) => {
  try {
    const deletado = await Usuario.findByIdAndDelete(req.params.id);
    if (!deletado) return res.status(404).json({ erro: "Usuário não encontrado" });
    res.status(204).send(); // No content
  } catch (err) {
    res.status(500).json({ erro: "Erro ao excluir usuário." });
  }
});

module.exports = router;
