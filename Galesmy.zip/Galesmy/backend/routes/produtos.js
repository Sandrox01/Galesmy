const express = require('express');
const router = express.Router();
const Produto = require('../models/Produto');

// GET todos os produtos
router.get('/', async (req, res) => {
  const produtos = await Produto.find();
  res.json(produtos);
});

// GET /api/produtos/:id
router.get('/:id', async (req, res) => {
  try {
    const produto = await Produto.findById(req.params.id);
    if (!produto) return res.status(404).json({ erro: "Produto não encontrado" });
    res.json(produto);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao buscar produto" });
  }
});

// POST novo produto
router.post('/', async (req, res) => {
  try {
    const novo = new Produto(req.body);
    const salvo = await novo.save();
    res.status(201).json(salvo);
  } catch (err) {
    res.status(400).json({ erro: 'Erro ao salvar produto' });
  }
});

// PUT /api/produtos/:id
router.put('/:id', async (req, res) => {
  try {
    const atualizado = await Produto.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!atualizado) return res.status(404).json({ erro: "Produto não encontrado" });
    res.json(atualizado);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao atualizar produto" });
  }
});

// DELETE /api/produtos/:id
router.delete('/:id', async (req, res) => {
  try {
    await Produto.findByIdAndDelete(req.params.id);
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ erro: 'Erro ao deletar produto.' });
  }
});

module.exports = router;
